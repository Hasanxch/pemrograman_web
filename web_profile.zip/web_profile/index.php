<!DOCTYPE html>


<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Mangrove</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
	<link href="css/font-awesome.min.css" rel="stylesheet"/>
	<link rel="shortcut icon" type="image/png" href="img/camera-icon.png"/>
</head>
<body>
	<section class="intro">
		<nav>
			<a href="#" id="menu-icon"></a>
			<ul>
				<li><a href="#about">Tentang</a></li>
				<li><a href="#port">Portofolio</a></li>
				<li><a href="#skill">Skill</a></li>
				<li><a href="#contact">Kontak</a></li>
				<li><a href="#jadwal"></a></li>
			</ul>
		</nav>
		<div class="inner">
			<div class="content">
				<h1>Hasan Mangrove</h1>
				<p>karena ma'ruf pake '</p>
			</div>
		</div>
	</section>
	<a name="about">
<div class="clearfix"></div>
	<section class="left-col">
		<h2>Tentang</h2>
		<p style="text-indent: 6%;">Hai, nama saya Hasan Ma'ruf. Biasa dipanggil Hasan. Saya lahir di Blitar 20 tahun yang lalu. Saya sekarang kuliah di UIN Sunan Kalijaga. Kali ini saya sedang mengerjakan tugas membuat wesite. Jangan di bully ya, saya masih noob. :)</p>
	</section>
	<section class="sidebar">
		<img src="img/sidebar.JPG">
	</section>
<div class="clearfix"></div>
	<a name="port">
		<h2>Portofolio</h2>
		<section class="one-third-port">
			<a href="#" target="_blank"><img src="img/photography-1.png"></a>
		</section>
		<section class="one-third-port">
			<a href="#" target="_blank"><img src="img/photography-2.png"></a>
		</section>
		<section class="one-third-port">
			<a href="https://hasanmangrove.blogspot.co.id/2016/12/rangkaian-lampion-suroboyo-carnival-park.html" target="_blank"><img src="img/photography-3.png"></a>
		</section>
		<section class="one-third-port">
			<a href="#" target="_blank"><img src="img/photography-4.png"></a>
		</section>
		<section class="one-third-port">
			<a href="#" target="_blank"><img src="img/photography-5.png"></a>
		</section>
		<section class="one-third-port">
			<a href="#" target="_blank"><img src="img/photography-6.png"></a>
		</section>
<div class="clearfix"></div>
	<a name="skill">
	<section class="left-col">
		<h2>Skill</h2>
			<p style="text-indent: 6%;">Sejak kecil saya sudah hobi bermain komputer. Pengalaman pertama menggunakan komputer sungguh tak terlupakan. Dari situ saya mulai mendalaminya. Selain komputer, saya juga bisa menyapu, memasak, mencuci, dan mencuri baju tetangga. </p>
	</section>
	<section class="sidebar">
		<section class="contact">
			<p>Coding <br class="break"> Fotografi <br class="break"> Makanan <br class="break"> Programmer <br class="break"> Videografi <br class="break"> Menyapu <br class="break"> Merayu</p>
		</section>
	</section>

	<!-- jadwal kuliah mulai dari sini -->
        <!--
	<div class="clearfix"></div>
	<h2>Jadwal kuliah</h2>
	<style media="screen">
		table {
			border-collapse: collapse;
		}
		table thead tr {
			background-color: #4CAFFF;
			color: white;
		}
		table th, td {
			padding: 10px;
			text-align: left;
		}
		table tr:hover {
			background-color: #f5f5f5;
		}
		table tr:nth-child(even) {
			background-color: #f2f2f2;
		}

	</style>
        
	<div style="overflow-x:auto;" class="jadwal">
		<table align="center">
			<thead>
				<tr>
					<td><b>Nomer</b></td>
					<td><b>Makul</b></td>
					<td><b>Ruang</b></td>
					<td><b>Dosen</b></td>
					<td><b>Waktu</b></td>
				</tr>
			</thead>
			<tbody>
                                
				<?php
                                /*
				include "conn.php";
				$sql = "SELECT id_jadwal, nama, ruang, dosen, waktu FROM jadwal_kuliah";
			  $result = $conn->query($sql);

				foreach ($result as $isi) {
					echo "<tr>";
					echo 	"<td>";
					echo 		$isi['id_jadwal'];
					echo 	"</td>";
					echo 	"<td>";
					echo 		$isi['nama'];
					echo 	"</td>";
					echo 	"<td>";
					echo 		$isi['ruang'];
					echo 	"</td>";
					echo 	"<td>";
					echo 		$isi['dosen'];
					echo 	"</td>";
					echo 	"<td>";
					echo 		$isi['waktu'];
					echo 	"</td>";
					echo "</tr>";
				}

				$conn->close();
                                */
				?>
                                
			</tbody>
		</table>
	</div>
        -->


<div class="clearfix"></div>
	<a name="contact">
		<section class="parallax">
			<div class="parallax-inner">
			</div>
		</section>
<div class="clearfix"></div>
	<h2>Kontak</h2>
	<section class="contact">
		<p>Email saja ke <br class="break"> <a href="mailto:hasanxch@gmail.com">hasanxch@gmail.com</a> <br class="break"> 0857-4546-2845</p>
		<p>Jl. Maju Mundur 1/7 <br class="break"> Blitar <br class="break"> Jawa Timur <br class="break"> 66183</p>
	</section>
<div class="clearfix"></div>
	<footer>
		<ul class="social">
			<li><a href="https://www.facebook.com/hasanxch" target="_blank"><i class="fa fa-facebook"></i></a></li>
			<li><a href="#" target="_blank"><i class="fa fa-google-plus"></i></a></li>
			<li><a href="https://twitter.com/HasanRuf" target="_blank"><i class="fa fa-twitter"></i></a></li>
			<li><a href="#" target="_blank"><i class="fa fa-youtube"></i></a></li>
			<li><a href="https://www.instagram.com/hasanmangrove" target="_blank"><i class="fa fa-instagram"></i></a></li>
		</ul>
	</footer>
	<footer class="second">
		<p>&copy; Mangrove</p>
	</footer>
</body>
</html>
